#!/usr/bin/env bash
set -euo pipefail

# Run this once on a development computer with Git, JDK 17+, Android SDK,
# and Android SDK Platform/Build Tools installed. The resulting app runs offline.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_TOOLS="$ROOT/.build-tools"
REPO="$BUILD_TOOLS/apktool-android"
TAG="v1.0.0"

mkdir -p "$BUILD_TOOLS"
if [ ! -d "$REPO/.git" ]; then
  git clone --depth 1 --branch "$TAG" https://github.com/anirudhmalik/apktool-android.git "$REPO"
else
  git -C "$REPO" fetch --tags --depth 1 origin "$TAG"
  git -C "$REPO" checkout "$TAG"
fi

(
  cd "$REPO"
  ./gradlew :brut.apktool:apktool-android:assembleRelease \
            :brut.apktool:apktool-android:collectRuntimeJars
)

AAR="$REPO/brut.apktool/apktool-android/build/outputs/aar/apktool-android-release.aar"
JARS="$REPO/brut.apktool/apktool-android/build/libs-bundle"

test -f "$AAR" || {
  echo "ERROR: AAR not found at $AAR" >&2
  exit 1
}
test -d "$JARS" || {
  echo "ERROR: runtime JAR bundle not found at $JARS" >&2
  exit 1
}

DEST="$ROOT/app/libs/apktool"
mkdir -p "$DEST/runtime"
cp "$AAR" "$DEST/apktool-android-1.0.0.aar"
find "$DEST/runtime" -maxdepth 1 -type f -name '*.jar' -delete
find "$JARS" -maxdepth 1 -type f -name '*.jar' -exec cp {} "$DEST/runtime/" \;

echo
echo "Apktool Android v1.0.0 integrated:"
echo "  AAR: $DEST/apktool-android-1.0.0.aar"
echo "  runtime JARs: $(find "$DEST/runtime" -maxdepth 1 -name '*.jar' | wc -l)"
echo "Now open the project in Android Studio and build the app."
