package com.example.apkrenamer

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.android.apksig.ApkSigner
import com.android.apksig.ApkVerifier
import java.io.File
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Calendar
import javax.security.auth.x500.X500Principal

/**
 * APK rewrite pipeline:
 * Apktool Android decode -> update manifest + text references -> rebuild
 * -> AndroidKeyStore signing -> apksig verification -> package-name verification.
 *
 * Apktool is loaded reflectively so the UI project can sync before the matching
 * Android AAR/runtime JAR bundle has been added. The engine will not run until
 * that dependency bundle is present.
 */
class ApkRewriteEngine(private val context: Context) {

    fun rewrite(inputApk: File, oldPackage: String, newPackage: String): File {
        require(inputApk.exists() && inputApk.isFile && inputApk.length() > 0L) {
            "找不到有效的输入 APK。"
        }
        require(isValidPackageName(newPackage)) { "新包名格式不正确。" }
        require(oldPackage.isNotBlank()) { "无法读取原包名。" }
        require(oldPackage != newPackage) { "新包名与原包名相同，无需修改。" }

        val workRoot = File(context.cacheDir, "apk-renamer-work").apply {
            if (exists()) deleteRecursively()
            check(mkdirs()) { "无法创建工作目录。" }
        }
        val decodedDir = File(workRoot, "decoded").apply { mkdirs() }
        val unsignedApk = File(workRoot, "rebuilt-unsigned.apk")
        val outputDir = File(context.filesDir, "apk-renamer-output").apply { mkdirs() }
        val signedApk = File(
            outputDir,
            "${inputApk.nameWithoutExtension}_${newPackage.replace('.', '_')}_signed.apk"
        )
        signedApk.delete()

        try {
            val config = configureApktool()
            invokeBooleanSetter(config, "setForced", true)

            decodeApk(inputApk, decodedDir, config)
            require(decodedDir.exists() && File(decodedDir, "AndroidManifest.xml").exists()) {
                "APK 反编译失败，未找到解码后的 AndroidManifest.xml。"
            }

            val rewriteCount = rewriteTextReferences(decodedDir, oldPackage, newPackage)
            updateManifestPackage(decodedDir, oldPackage, newPackage)

            buildApk(decodedDir, unsignedApk, config)
            require(unsignedApk.exists() && unsignedApk.length() > 0L) {
                "APK 重建失败，没有生成输出文件。"
            }

            signApk(unsignedApk, signedApk)
            verifySignature(signedApk)
            verifyPackageName(signedApk, newPackage)

            // Keep only the output artifact in persistent app storage.
            workRoot.deleteRecursively()
            return signedApk
        } catch (t: Throwable) {
            signedApk.delete()
            val cause = unwrapInvocation(t)
            workRoot.deleteRecursively()
            throw IllegalStateException(
                friendlyError(cause),
                cause
            )
        }
    }

    private fun configureApktool(): Any {
        val entry = try {
            Class.forName("brut.androlib.android.ApktoolAndroid")
        } catch (e: ClassNotFoundException) {
            throw IllegalStateException(
                "缺少 Apktool Android 引擎。请先运行项目 scripts/setup-apktool-android.sh，" +
                    "把 v1.0.0 AAR 和配套 runtime JAR 放入 app/libs/apktool/。"
            )
        }

        val method = entry.methods.firstOrNull {
            it.name == "configure" &&
                it.parameterTypes.size == 1 &&
                Context::class.java.isAssignableFrom(it.parameterTypes[0])
        } ?: throw IllegalStateException("Apktool Android 版本不匹配：找不到 configure(Context)。")

        val receiver = if (java.lang.reflect.Modifier.isStatic(method.modifiers)) {
            null
        } else {
            runCatching { entry.getField("INSTANCE").get(null) }.getOrNull()
        }

        return method.invoke(receiver, context)
            ?: throw IllegalStateException("Apktool Android 初始化失败。")
    }

    private fun decodeApk(input: File, decoded: File, config: Any) {
        val decoderClass = Class.forName("brut.androlib.ApkDecoder")
        val decoder = constructWithConfig(decoderClass, input, config)
        val decode = decoderClass.methods.firstOrNull {
            it.name == "decode" &&
                it.parameterTypes.size == 1 &&
                it.parameterTypes[0] == File::class.java
        } ?: throw IllegalStateException("Apktool API 不匹配：找不到 ApkDecoder.decode(File)。")
        decode.invoke(decoder, decoded)
    }

    private fun buildApk(decoded: File, output: File, config: Any) {
        val builderClass = Class.forName("brut.androlib.ApkBuilder")
        val builder = constructWithConfig(builderClass, decoded, config)
        val build = builderClass.methods.firstOrNull {
            it.name == "build" &&
                it.parameterTypes.size == 1 &&
                it.parameterTypes[0] == File::class.java
        } ?: throw IllegalStateException("Apktool API 不匹配：找不到 ApkBuilder.build(File)。")
        build.invoke(builder, output)
    }

    private fun constructWithConfig(clazz: Class<*>, file: File, config: Any): Any {
        val constructor = clazz.constructors.firstOrNull { ctor ->
            val p = ctor.parameterTypes
            p.size == 2 &&
                p[0].isAssignableFrom(File::class.java) &&
                p[1].isInstance(config)
        } ?: throw IllegalStateException("Apktool API 不匹配：找不到 ${clazz.simpleName}(File, Config)。")
        return constructor.newInstance(file, config)
    }

    private fun invokeBooleanSetter(target: Any, methodName: String, value: Boolean) {
        val setter = target.javaClass.methods.firstOrNull {
            it.name == methodName &&
                it.parameterTypes.contentEquals(arrayOf(Boolean::class.javaPrimitiveType))
        }
        setter?.invoke(target, value)
    }

    /**
     * Rewrites UTF-8 text payloads rather than relying only on filename extensions.
     * Binary assets are skipped (NUL byte or invalid UTF-8). This catches smali,
     * decoded XML, JSON, properties, text assets, and other plain-text files.
     */
    private fun rewriteTextReferences(root: File, oldPackage: String, newPackage: String): Int {
        val oldSlash = oldPackage.replace('.', '/')
        val newSlash = newPackage.replace('.', '/')
        var changedFiles = 0

        root.walkTopDown()
            .filter { it.isFile && it.length() in 1..(16L * 1024L * 1024L) }
            .forEach { file ->
                val bytes = runCatching { file.readBytes() }.getOrNull() ?: return@forEach
                if (bytes.any { it == 0.toByte() }) return@forEach

                val decoded = runCatching {
                    StandardCharsets.UTF_8.newDecoder()
                        .onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(bytes))
                        .toString()
                }.getOrNull() ?: return@forEach

                if (!decoded.contains(oldPackage) && !decoded.contains(oldSlash)) {
                    return@forEach
                }

                val changed = decoded
                    .replace(oldPackage, newPackage)
                    .replace(oldSlash, newSlash)

                if (changed != decoded) {
                    file.writeText(changed, StandardCharsets.UTF_8)
                    changedFiles++
                }
            }

        return changedFiles
    }

    private fun updateManifestPackage(root: File, oldPackage: String, newPackage: String) {
        val manifest = File(root, "AndroidManifest.xml")
        require(manifest.exists()) { "反编译目录中缺少 AndroidManifest.xml。" }

        val xml = manifest.readText(StandardCharsets.UTF_8)
        val rootPackage = Regex("""(?s)(<manifest\b[^>]*?\bpackage\s*=\s*")[^"]+(")""")
        val match = rootPackage.find(xml)
            ?: throw IllegalStateException("无法定位 Manifest 根节点的 package 属性。")

        val actualPackage = match.value.substringAfter("package").substringAfter('=')
            .trim().removePrefix("\"").removeSuffix("\"")

        require(actualPackage == oldPackage || actualPackage == newPackage) {
            "Manifest 中的包名与解析到的原包名不一致，已停止修改以避免损坏 APK。"
        }

        val updated = rootPackage.replaceFirst(xml) { m ->
            m.groupValues[1] + newPackage + m.groupValues[2]
        }
        manifest.writeText(updated, StandardCharsets.UTF_8)
    }

    private fun signApk(unsignedApk: File, outputApk: File) {
        val (privateKey, certChain) = getOrCreateSigningIdentity()
        require(certChain.isNotEmpty()) { "本机签名证书链为空。" }

        val signerConfig = ApkSigner.SignerConfig.Builder(
            "APK Renamer Local",
            privateKey,
            certChain
        ).build()

        ApkSigner.Builder(listOf(signerConfig))
            .setInputApk(unsignedApk)
            .setOutputApk(outputApk)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .setV4SigningEnabled(false)
            .build()
            .sign()
    }

    private fun verifySignature(apk: File) {
        val result = ApkVerifier.Builder(apk).build().verify()
        if (!result.isVerified) {
            val errors = result.errors.joinToString("\n") { it.toString() }
            throw IllegalStateException("APK 签名验证失败：\n$errors")
        }
    }

    @Suppress("DEPRECATION")
    private fun verifyPackageName(apk: File, expected: String) {
        val info = if (Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getPackageArchiveInfo(
                apk.absolutePath,
                PackageManager.PackageInfoFlags.of(0L)
            )
        } else {
            context.packageManager.getPackageArchiveInfo(apk.absolutePath, 0)
        } ?: throw IllegalStateException("重建后的 APK 无法被系统解析。")

        require(info.packageName == expected) {
            "输出包名校验失败：预期 $expected，实际 ${info.packageName}。"
        }
    }

    private fun getOrCreateSigningIdentity(): Pair<PrivateKey, List<X509Certificate>> {
        val alias = "apk-renamer-local-signing-v1"
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

        if (!keyStore.containsAlias(alias)) {
            val start = Calendar.getInstance()
            val end = Calendar.getInstance().apply { add(Calendar.YEAR, 25) }

            val spec = KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
            )
                .setKeySize(2048)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                .setCertificateSubject(X500Principal("CN=APK Renamer Local Key"))
                .setCertificateSerialNumber(BigInteger.ONE)
                .setCertificateNotBefore(start.time)
                .setCertificateNotAfter(end.time)
                .setUserAuthenticationRequired(false)
                .build()

            KeyPairGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_RSA,
                "AndroidKeyStore"
            ).apply {
                initialize(spec)
                generateKeyPair()
            }
        }

        val privateKey = keyStore.getKey(alias, null) as? PrivateKey
            ?: throw IllegalStateException("无法读取本机签名私钥。")
        val certificates = keyStore.getCertificateChain(alias)
            ?.mapNotNull { it as? X509Certificate }
            .orEmpty()

        return privateKey to certificates
    }

    private fun unwrapInvocation(t: Throwable): Throwable {
        var current = t
        while (current.cause != null &&
            (current is java.lang.reflect.InvocationTargetException ||
                current is java.lang.reflect.UndeclaredThrowableException)
        ) {
            current = current.cause!!
        }
        return current
    }

    private fun friendlyError(t: Throwable): String {
        val message = t.message.orEmpty()
        return when {
            t is ClassNotFoundException ->
                "Apktool 运行库不完整：缺少 ${t.message}。请重新运行依赖集成脚本。"
            message.contains("Permission denied", ignoreCase = true) ->
                "系统不允许执行内置 AAPT2。当前鸿蒙兼容环境可能限制了原生程序执行。"
            message.contains("OutOfMemory", ignoreCase = true) ->
                "处理时内存不足。请关闭其他应用后重试，或先使用较小的 APK 测试。"
            message.contains("aapt", ignoreCase = true) ->
                "AAPT2 资源重建失败：$message"
            else -> message.ifBlank { "APK 修改失败，请检查 APK 是否完整或是否使用了加固/特殊构建格式。" }
        }
    }

    private fun isValidPackageName(value: String): Boolean =
        Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$").matches(value)
}
