package com.example.apkrenamer

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ApkRenamerScreen()
                }
            }
        }
    }
}

private data class ApkSelection(
    val file: File,
    val label: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long
)

@Composable
private fun ApkRenamerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var selection by remember { mutableStateOf<ApkSelection?>(null) }
    var newPackage by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("请选择一个 APK 文件开始。") }
    var error by remember { mutableStateOf<String?>(null) }
    var outputFile by remember { mutableStateOf<File?>(null) }
    var runtimeReport by remember { mutableStateOf("尚未检测。建议先在卓易通内运行本工具，再检测 AAPT2 原生执行能力。") }
    var checkingRuntime by remember { mutableStateOf(false) }

    val openApk = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            busy = true
            error = null
            outputFile = null
            status = "正在读取 APK 信息…"
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) {
                        val input = File(
                            context.cacheDir,
                            "selected_${System.currentTimeMillis()}.apk"
                        )
                        context.contentResolver.openInputStream(uri)?.use { source ->
                            input.outputStream().use { target -> source.copyTo(target) }
                        } ?: error("无法读取所选文件。")

                        require(input.length() > 0L) { "所选文件为空。" }
                        val info = readArchivePackageInfo(context.packageManager, input)
                            ?: error("无法解析此文件。请确认它是完整的单体 APK，而不是 XAPK/APKS/APKM。")

                        val appInfo = info.applicationInfo
                            ?: error("APK 缺少应用信息。")
                        appInfo.sourceDir = input.absolutePath
                        appInfo.publicSourceDir = input.absolutePath
                        val label = runCatching {
                            context.packageManager.getApplicationLabel(appInfo).toString()
                        }.getOrDefault("未知应用")

                        ApkSelection(
                            file = input,
                            label = label,
                            packageName = info.packageName.orEmpty(),
                            versionName = info.versionName ?: "未知",
                            versionCode = if (Build.VERSION.SDK_INT >= 28) {
                                info.longVersionCode
                            } else {
                                @Suppress("DEPRECATION")
                                info.versionCode.toLong()
                            }
                        )
                    }
                    selection = result
                    newPackage = result.packageName
                    status = "APK 解析成功，可以输入新的包名。"
                } catch (t: Throwable) {
                    error = t.message ?: "读取失败"
                    status = "读取失败。"
                } finally {
                    busy = false
                }
            }
        }
    }

    val saveApk = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri: Uri? ->
        val file = outputFile
        if (uri != null && file != null) {
            busy = true
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            file.inputStream().use { input -> input.copyTo(out) }
                        } ?: error("无法创建目标文件。")
                    }
                    status = "APK 已保存到你选择的位置。"
                } catch (t: Throwable) {
                    error = t.message ?: "保存失败"
                    status = "保存失败。"
                } finally {
                    busy = false
                }
            }
        }
    }

    val canRewrite = !busy &&
        selection != null &&
        isValidPackageName(newPackage) &&
        selection?.packageName != newPackage

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "APK 包名修改器",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "V0.3 · 卓易通适配验证版 · 本地离线处理",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("卓易通运行环境检测", fontWeight = FontWeight.SemiBold)
                Text(
                    "请把本工具安装并运行在卓易通环境中。检测会尝试执行内置 AAPT2；这是判断能否在当前兼容容器内重建 APK 的关键一步。",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = {
                        checkingRuntime = true
                        scope.launch {
                            runtimeReport = withContext(Dispatchers.IO) {
                                RuntimeDiagnostics.check(context)
                            }
                            checkingRuntime = false
                        }
                    },
                    enabled = !busy && !checkingRuntime,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (checkingRuntime) "正在检测…" else "检测当前运行环境")
                }
                if (checkingRuntime) CircularProgressIndicator()
                Text(runtimeReport, style = MaterialTheme.typography.bodySmall)
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("第一步：选择 APK", fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { openApk.launch(arrayOf("*/*")) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("选择 APK 文件")
                }
                selection?.let { apk ->
                    HorizontalDivider()
                    InfoLine("应用名称", apk.label)
                    InfoLine("原包名", apk.packageName)
                    InfoLine("版本", "${apk.versionName} (${apk.versionCode})")
                    InfoLine("文件大小", formatBytes(apk.file.length()))
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("第二步：设置新包名", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = newPackage,
                    onValueChange = {
                        newPackage = it
                        error = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("新的包名 / applicationId") },
                    placeholder = { Text("例如 com.example.newapp") },
                    supportingText = {
                        Text("至少两段；每段以英文字母开头，只允许英文字母、数字和下划线。")
                    },
                    isError = newPackage.isNotBlank() && !isValidPackageName(newPackage)
                )
                if (selection?.packageName == newPackage && newPackage.isNotBlank()) {
                    Text(
                        "新包名不能与原包名相同。",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        Button(
            onClick = {
                val apk = selection ?: return@Button
                busy = true
                error = null
                outputFile = null
                status = "正在反编译、替换包名、重建、签名和验证…"
                scope.launch {
                    try {
                        val result = withContext(Dispatchers.IO) {
                            ApkRewriteEngine(context).rewrite(
                                inputApk = apk.file,
                                oldPackage = apk.packageName,
                                newPackage = newPackage
                            )
                        }
                        outputFile = result
                        status = "完成：新 APK 已重建、签名，并验证包名与签名。"
                    } catch (t: Throwable) {
                        error = t.message ?: "处理失败"
                        status = "处理未完成。原始 APK 未被修改。"
                    } finally {
                        busy = false
                    }
                }
            },
            enabled = canRewrite,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("开始修改并重新签名")
        }

        outputFile?.let { file ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("第三步：导出 APK", fontWeight = FontWeight.SemiBold)
                    Text(file.name, style = MaterialTheme.typography.bodySmall)
                    Text(formatBytes(file.length()), style = MaterialTheme.typography.labelSmall)
                    Button(
                        onClick = { saveApk.launch(file.name) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("保存修改后的 APK")
                    }
                }
            }
        }

        if (busy) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CircularProgressIndicator()
                Text("正在处理，请保持应用在前台。大型 APK 可能需要较长时间。")
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("处理状态", fontWeight = FontWeight.SemiBold)
                Text(status)
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        }

        Text(
            text = "注意：重新签名后不能直接覆盖安装原签名版本。加固、拆分包、native 代码硬编码包名、签名校验或服务器校验可能导致修改后的应用无法运行。请只处理自己拥有或获授权的 APK。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Suppress("DEPRECATION")
private fun readArchivePackageInfo(pm: PackageManager, file: File): PackageInfo? {
    return if (Build.VERSION.SDK_INT >= 33) {
        pm.getPackageArchiveInfo(
            file.absolutePath,
            PackageManager.PackageInfoFlags.of(
                (PackageManager.GET_ACTIVITIES or PackageManager.GET_PROVIDERS).toLong()
            )
        )
    } else {
        pm.getPackageArchiveInfo(
            file.absolutePath,
            PackageManager.GET_ACTIVITIES or PackageManager.GET_PROVIDERS
        )
    }
}

private fun isValidPackageName(value: String): Boolean =
    Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$").matches(value)

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    return String.format("%.1f MB", kb / 1024.0)
}
