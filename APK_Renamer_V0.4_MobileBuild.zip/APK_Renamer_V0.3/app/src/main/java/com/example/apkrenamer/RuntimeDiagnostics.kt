package com.example.apkrenamer

import android.content.Context
import android.os.Build
import java.io.File

/** Checks the exact native AAPT2 execution path used by apktool-android. */
object RuntimeDiagnostics {
    fun check(context: Context): String {
        val abi = Build.SUPPORTED_ABIS.joinToString()
        val nativeDir = context.applicationInfo.nativeLibraryDir.orEmpty()
        val aapt = File(nativeDir, "libaapt2.so")
        val header = buildString {
            appendLine("系统 API：${Build.VERSION.SDK_INT}")
            appendLine("设备 ABI：$abi")
            appendLine("Native 目录：$nativeDir")
            appendLine("AAPT2：${aapt.absolutePath}")
            appendLine("文件存在：${aapt.exists()}")
            appendLine("可执行标记：${aapt.canExecute()}")
        }

        if (!aapt.exists()) {
            return header + "\n结果：未找到 libaapt2.so。请先集成 apktool-android AAR，并确认打包包含当前设备 ABI。"
        }

        return try {
            val process = ProcessBuilder(aapt.absolutePath, "version")
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
            val exitCode = process.waitFor()
            header + "\nAAPT2 退出码：$exitCode\n输出：${output.ifBlank { "（无输出）" }}\n" +
                if (exitCode == 0) {
                    "\n结果：原生 AAPT2 可以启动。下一步可测试完整 APK 解包/重建流程；这不等于所有 APK 都兼容。"
                } else {
                    "\n结果：文件存在但无法正常执行。卓易通可能限制了原生程序执行，或当前 ABI/打包方式不匹配。"
                }
        } catch (t: Throwable) {
            header + "\n结果：执行 AAPT2 失败：${t.javaClass.simpleName}: ${t.message}"
        }
    }
}
