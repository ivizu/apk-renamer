plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.apkrenamer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.apkrenamer"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        jniLibs {
            // Required so the Android-packaged libaapt2.so can be executed.
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.version",
                "prebuilt/linux/**",
                "prebuilt/macosx/**",
                "prebuilt/windows/**"
            )
        }
    }

    androidResources {
        noCompress += "apk"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.02.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.android.tools.build:apksig:8.9.1")

    // The AAR is a thin Android wrapper. Its matching runtime JAR bundle is mandatory.
    // Run scripts/setup-apktool-android.sh once before building a functional APK.
    val apktoolAar = file("libs/apktool/apktool-android-1.0.0.aar")
    if (apktoolAar.exists()) {
        implementation(files(apktoolAar))
    }
    val apktoolRuntime = file("libs/apktool/runtime")
    if (apktoolRuntime.exists()) {
        implementation(fileTree(apktoolRuntime) { include("*.jar") })
    }
}
