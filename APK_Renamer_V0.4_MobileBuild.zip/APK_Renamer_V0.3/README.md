# APK Renamer V0.2 — APK 包名修改器

面向 Android / HarmonyOS 兼容环境的本地 APK 包名修改器源码工程。

## V0.3 本轮改进

- 增加“卓易通运行环境检测”卡片。
- 显示当前 Android API、ABI、nativeLibraryDir、AAPT2 文件是否存在。
- 尝试在应用进程中执行 `libaapt2.so version`，提前判断卓易通是否允许执行原生 AAPT2。
- 这个检测只验证 AAPT2 能否启动，不代表所有 APK 均可成功改包。

## V0.2 本轮改进

- 使用 `apktool-android v1.0.0` 的真实 API 结构：`ApktoolAndroid.configure(Context)`、`ApkDecoder(File, Config).decode(File)`、`ApkBuilder(File, Config).build(File)`。
- 加入一键依赖集成脚本 `scripts/setup-apktool-android.sh`。
- 文本引用替换不再只看扩展名，而是尝试严格 UTF-8 解码；二进制资源自动跳过。
- 修改 Manifest 根节点的 `package` 前先核对原包名，避免错误替换。
- 重建后检查 APK 能否被 Android PackageManager 解析、包名是否等于目标值。
- 重新签名后调用 apksig 验证签名。
- 输出放在应用私有持久目录，再由系统文件选择器导出。
- 保留原 APK 不变；任何步骤失败都会删除不完整输出。

## 重要说明：引擎依赖必须先集成

本项目将 Apktool Android 的 AAR 与 runtime JAR 分开引入。官方 USAGE 明确说明：只放 AAR 不够，AAR 内的 `classes.jar` 只有薄封装，Apktool 主库和其他依赖必须通过 runtime JAR bundle 提供。

在装有 Git、JDK 17+、Android SDK 的开发电脑上，于项目根目录执行：

```bash
bash scripts/setup-apktool-android.sh
```

脚本会固定使用 `apktool-android v1.0.0`，构建 AAR 和 `collectRuntimeJars`，再复制到：

```text
app/libs/apktool/
├── apktool-android-1.0.0.aar
└── runtime/
    ├── apktool-lib.jar
    ├── brut.j.common.jar
    └── 其他配套运行库.jar
```

AAR 和 JAR 必须来自同一 tag/commit，不要混用版本。

上游集成说明：
https://github.com/anirudhmalik/apktool-android/blob/v1.0.0/USAGE.md

上游 Release：
https://github.com/anirudhmalik/apktool-android/releases/tag/v1.0.0

## 构建

要求：
- Android Studio（AGP 8.9.1）
- JDK 17
- Android SDK Platform 35
- Android SDK Build Tools

步骤：
1. 解压本项目。
2. 运行上面的依赖集成脚本。
3. 用 Android Studio 打开项目根目录。
4. 等待 Gradle Sync。
5. 选择 `app` 运行配置，构建 Debug APK。

如果没有集成 Apktool AAR/runtime JAR，项目 UI 仍可同步，但实际修改时会提示缺少引擎。

## HarmonyOS 6 兼容性

本工程产物是 Android APK，不是原生 HarmonyOS HAP。目标设备需要能够通过卓易通等兼容服务安装并运行 Android 应用。

Apktool Android 需要：
- `minSdk 26`
- `arm64-v8a`、`armeabi-v7a` 或 `x86_64` 对应的 `libaapt2.so`
- `packaging { jniLibs { useLegacyPackaging = true } }`
- 允许应用在自身 nativeLibraryDir 执行 `libaapt2.so`

即使 APK 能启动，鸿蒙兼容容器也可能阻止 native AAPT2 运行。必须在你的具体 HarmonyOS 6 机型上实测，不能仅凭源码保证兼容。

## 修改范围与边界

本工具会处理 Apktool 解码后的：
- AndroidManifest.xml 根包名
- 解码后的 XML / YAML / smali / JSON / properties 等 UTF-8 文本中的原包名（点分和斜杠形式）
- smali 中常见的类描述符与包路径引用

但不能保证所有 APK 都能完整改名。以下情况可能失败或改名后无法运行：
- 加固、壳、加密 DEX、自定义 ClassLoader
- 原生 `.so` 中硬编码的包名
- 加密或非 UTF-8 的资源/配置
- 多 APK split、`.apks`、`.xapk`、`.apkm`
- 共享 UID、签名级权限、证书指纹校验、Play Integrity 或服务器包名校验
- 特殊 OEM 构建格式或 Apktool 无法解码的 APK

## 签名与安装

修改后 APK 使用本工具在 AndroidKeyStore 中生成的本机签名密钥重新签名：
- 不能覆盖安装原开发者签名的 APK。
- 通常需要先卸载原应用，再安装修改版。
- 卸载原应用可能导致其本地数据丢失，请先备份。
- 本工具的本机签名密钥保存在 AndroidKeyStore；清除应用数据/卸载本工具可能影响后续使用同一签名密钥的能力。

## 参考与致谢

- Apktool 官方 FAQ：https://apktool.org/docs/faq/
- Apktool Android 封装：https://github.com/anirudhmalik/apktool-android
- Apktool Android USAGE：https://github.com/anirudhmalik/apktool-android/blob/v1.0.0/USAGE.md
- apksig：Android APK signing and verification library

请只修改你拥有或获授权处理的 APK，并保留原始文件备份。


## 你的目标环境：HarmonyOS 6 + 卓易通（选项 A）

这版按“APK Renamer 自身运行在卓易通提供的 Android 兼容环境中”设计，而不是把 APK 当作鸿蒙原生 HAP。

建议测试顺序：
1. 先确认卓易通已更新到最新版，并按卓易通自身支持的方式安装/启动 APK Renamer。华为说明：HarmonyOS 5 及以上互联网下载的 APK 是否可安装，以卓易通实际支持为准。
2. 在卓易通内打开 APK Renamer，点击“检测当前运行环境”。
3. 若 `libaapt2.so` 不存在，说明 AAR/ABI 未正确打包；若文件存在但执行失败，说明兼容容器可能不允许执行原生 AAPT2。
4. 若 AAPT2 检测通过，再用一个自己开发的简单测试 APK 做 decode → rebuild → sign → verify 全流程测试。
5. 最后再测试真实目标 APK；不要先拿带支付、登录或风控的生产 APK 试验。

HarmonyOS 6 的卓易通官方 FAQ 说明，HarmonyOS 6.0 及以上在满足版本条件时，卓易通应用可直接访问系统文件；旧版或未更新环境可能需要通过“文件互传”导入文件。实际界面以你设备上的卓易通版本为准。

华为官方还明确说明，互联网下载或分享来的 APK 是否支持安装，以卓易通实际支持为准。因此，不能承诺 Renamer APK 一定能被卓易通接纳安装，也不能承诺容器一定允许 `ProcessBuilder` 执行 AAPT2。

官方参考：
- 华为 HarmonyOS 5 及以上 APK 安装说明：https://consumer.huawei.com/cn/support/content/zh-cn16061787/
- 卓易通常见问题：https://www.droitong.com/CommonQues.html
- Apktool Android v1.0.0 AAPT2 ABI 与 `nativeLibraryDir` 执行要求：https://github.com/anirudhmalik/apktool-android/blob/v1.0.0/USAGE.md

## 没有电脑？用手机 + GitHub Actions 云端编译

本项目带有 `.github/workflows/build-apk.yml`，可在 GitHub 云端 Linux runner 自动下载 Android Apktool 依赖、配置 Android SDK 并编译 APK。手机只负责上传源码、点击运行和下载产物，不需要 Android Studio。

### 手机操作步骤

1. 在手机浏览器打开 https://github.com 并登录/注册 GitHub。
2. 点击 New repository，新建仓库，例如 `apk-renamer`。
   - 建议选择 Private，避免公开项目源码。
   - 私有仓库的 Actions 使用量受 GitHub 账户额度限制；若额度不足，需按 GitHub 页面提示处理。
3. 下载并解压本项目 ZIP。用手机文件管理器把解压后的 `APK_Renamer_V0.3` 文件夹里的所有内容上传到仓库根目录，必须包含 `.github` 隐藏目录。
   - 如果 GitHub 手机网页不方便上传整个目录，可用 GitHub 官方手机 App 或浏览器桌面版模式。
4. 上传完成后，打开仓库的 Actions 标签页，选择 `Build APK Renamer`。
5. 点击 `Run workflow`，再确认运行。
6. 等待任务变成绿色 `Success`。打开该次运行，向下找到 `Artifacts`，下载 `APK-Renamer-debug`。
7. 解压 artifact，得到 `app-debug.apk`。先在卓易通中安装并测试启动。

### 重要说明

- 首次构建会从公开上游仓库下载 Apktool Android v1.0.0，并在 GitHub runner 中构建其 AAR 与配套 runtime JAR；这些依赖不会放在本源码 ZIP 中。
- 云端编译只构建 APK Renamer 本身，不会把你准备修改的第三方 APK 上传到 GitHub。真正的 APK 包名修改仍设计为在手机本地执行。
- 请不要把任何待修改的 APK、签名私钥、密码或个人文件上传到 GitHub 仓库。
- GitHub Actions 工作流使用 `checkout`、Java 17、Android SDK、Gradle 8.11.1 和 artifact 上传步骤。GitHub Actions 官方文档说明了 Gradle 配置和 artifact 保存方式。
- 如果构建失败，打开 Actions 任务并复制最底部第一段 `FAILURE` / `What went wrong` 错误日志给我，我可以按日志继续修复。
